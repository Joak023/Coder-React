const CartWidget = () => {
    return (
      <div className="cart-widget">
        🛒 <span style={{ marginLeft: "5px" }}>Carrito</span>
      </div>
    );
  };

  export default CartWidget;